<?php
Redux::setSection('saasland_opt', array(
    'title'            => esc_html__( 'Job Settings', 'saasland' ),
    'id'               => 'job_opt',
    'icon'             => 'dashicons dashicons-clipboard',
    'fields'           => array(
        array(
            'title'     => esc_html__('Apply Form Shortcode', 'saasland'),
            'subtitle'  => __('Get the Job Apply form template from <a href="https://is.gd/N6sJVo" target="_blank">here.</a>', 'saasland'),
            'id'        => 'apply_form_shortcode',
            'type'      => 'text',
        ),
        array(
            'title'     => esc_html__('Apply Button Title', 'saasland'),
            'id'        => 'apply_btn_title',
            'type'      => 'text',
            'default'   => esc_html__('Apply Now', 'saasland')
        ),
        array(
            'title'     => esc_html__('Before Apply Form', 'saasland'),
            'subtitle'  => esc_html__('Place contents to show before the Apply Form', 'saasland'),
            'id'        => 'before_form',
            'type'      => 'editor',
            'args'    => array(
                'wpautop'       => true,
                'media_buttons' => false,
                'textarea_rows' => 10,
                //'tabindex' => 1,
                //'editor_css' => '',
                'teeny'         => false,
                //'tinymce' => array(),
                'quicktags'     => false,
            )
        ),
    )
));