<?php

// Footer settings
Redux::setSection('saasland_opt', array(
    'title'     => esc_html__('Slug Re-write', 'saasland'),
    'id'        => 'saasland_cp_slugs',
    'icon'      => 'dashicons dashicons-admin-links',
    'fields'    => array(
        
        array(
            'id'        => 'cp_slug_note',
            'type'      => 'info',
            'style'     => 'warning',
            'title'     => esc_html__( 'Warning:', 'saasland'),
            'icon'      => 'dashicons dashicons-info',
            'desc'      => sprintf (
                '%1$s <a href="%2$s"> %3$s</a> %4$s',
                esc_html__( 'These are the custom post\'s slugs offered by Saasland. You can customize the permalink structure (site_domain/post_type_slug/post_lug) by changing the slug from here. Save the permalinks settings from', 'saasland'),
                get_admin_url( null, 'options-permalink.php' ),
                esc_html__( 'Settings > Permalinks', 'saasland'),
                esc_html__( 'after changing the slug value.', 'saasland')
            )
        ),
        
        array(
            'title'     => esc_html__('Service Slug', 'saasland'),
            'id'        => 'service_slug',
            'type'      => 'text',
            'default'   => 'service'
        ),
        
        array(
            'title'     => esc_html__('Portfolio Slug', 'saasland'),
            'id'        => 'portfolio_slug',
            'type'      => 'text',
            'default'   => 'portfolio'
        ),
        
        array(
            'title'     => esc_html__('Case Study Slug', 'saasland'),
            'id'        => 'case_study_slug',
            'type'      => 'text',
            'default'   => 'case_study'
        ),

        array(
            'title'     => esc_html__('Jobs Slug', 'saasland'),
            'id'        => 'job_slug',
            'type'      => 'text',
            'default'   => 'job'
        ),
    )
));