<?php

// Color option
Redux::setSection('saasland_opt', array(
	'title'     => esc_html__('Color Settings', 'saasland'),
	'id'        => 'color',
	'icon'      => 'dashicons dashicons-admin-appearance',
	'fields'    => array(
        array(
            'id'          => 'accent_solid_color',
            'type'        => 'color',
            'title'       => esc_html__( 'Accent Color', 'saasland' ),
            'output'      => array(
                'color' => '
                    .menu > .nav-item:hover .nav-link, .error_page2 .header_area .menu > .nav-item:hover > .nav-link,
                    .blog_related_post .blog_list_item .blog_content a:hover, .blog .menu > .nav-item > .nav-link:hover,
                    .blog_list_item_two .blog_content .post-info-bottom .post-info-comments:hover,
                    .blog-sidebar .widget.widget_nav_menu ul li a:hover, .blog-sidebar .widget.widget_meta ul li a:hover, .blog-sidebar .widget.widget_pages ul  a:hover, 
                    .blog-sidebar .widget.widget_archive ul li:hover, .blog-sidebar .widget.widget_archive ul li a:hover, .blog-sidebar .widget.widget_categories ul li a:hover,
                    .menu > .nav-item.submenu .dropdown-menu .nav-item:hover > .nav-link, .menu > .nav-item.submenu .dropdown-menu .nav-item:focus > .nav-link,
                    .comment_inner .comment_box .post_comment .post_author_two .comment_reply:hover,
                    .blog_single_info .blog_list_item_two .blog_content .post-info-bottom .social_icon ul li a:hover,
                    .blog_list_item_two .blog_content .post-info-bottom .post-info-comments:hover,
                    .blog_list_item_two .blog_content .post-info-bottom .post-info-comments i,
                    .blog_single_info .blog_list_item_two blockquote::before, blockquote::before,
                    header.header_area.navbar_fixed .navbar .navbar-nav .menu-item a.nav-link.active,
                    .blog_list_item_two .blog_content .post-info-bottom .post-info-comments i,
                    .blog_list_item_two .post_date, .qutoe_post .blog_content i,
                    .menu > .nav-item.submenu .dropdown-menu .nav-item.active > .nav-link,
                    .widget_recent_comments #recentcomments .recentcomments:before,
                    .new_footer_top .f_widget.about-widget ul li a:hover,
                    header.header_area.navbar_fixed .navbar .navbar-nav .menu-item a:hover,
                    .widget_recent_comments #recentcomments .recentcomments a:hover,
                    .widget.recent_post_widget_two .post_item .media-body h3:hover,
                    .comments_widget ul li .comments_items .media-body p:hover,
                    .widget.recent_post_widget_two .post_item .media-body h3:hover,
                    .f_widget .widget-wrap p a:hover,
                    .pagination .nav-links .page-numbers:hover,
                    .widget.widget_recent_entries li a:hover,
                    .widget_rss ul li a.rsswidget:hover,
                    .form-submit input#submit:hover
                    ',
                'background-color' => '
                    .widget_recent_comments #recentcomments .recentcomments:hover:before,
                    .woocommerce-account #customer_login .button,
                    .blog_list_item .blog_content .single_post_tags.post-tags a:hover,
                    .blog_content .learn_btn_two:hover:before,
                    .pagination .nav-links .page-numbers.current,
                    .tagcloud a:hover, p.sticky-label,
                    .form-submit input#submit
                    ',
                'border-color' => '
                    .blog-sidebar .widget.widget_nav_menu ul li a:hover, .blog-sidebar .widget.widget_meta ul li a:hover, .blog-sidebar .widget.widget_pages ul li a:hover, 
                    .blog-sidebar .widget.widget_archive ul li:hover, .blog-sidebar .widget.widget_archive ul li a:hover, .blog-sidebar .widget.widget_categories ul li a:hover,
                    .widget.search_widget_two .search-form .form-control:focus,
                    .blog_comment_box .get_quote_form .form-group .form-control:focus,
                    .blog_list_item.format-audio .audio_player, .qutoe_post .blog_content,
                    .widget_recent_comments #recentcomments .recentcomments:before,
                    .blog_single_info .blog_list_item_two blockquote, blockquote,
                    .pagination .nav-links .page-numbers:hover,
                    .form-submit input#submit
                    ',
            ),
        ),

        array(
            'id'          => 'anchor_tag_color',
            'type'        => 'link_color',
            'title'       => esc_html__( 'Link Color', 'saasland' ),
            'output'      => '.blog_list_item .blog_content a, .blog_list_item .blog_content p a'
        )

	)
));

