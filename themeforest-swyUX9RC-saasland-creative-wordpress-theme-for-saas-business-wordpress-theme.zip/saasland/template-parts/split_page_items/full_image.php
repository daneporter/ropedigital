<?php
$full_image = get_sub_field('image');

if ( !empty($image['url']) ) :
    ?>
    <div class="split_banner height" >
    </div>
    <?php
endif;