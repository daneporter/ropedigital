<?php

// Image sizes
add_image_size('saasland_370x360', 370, 360, true); // Posts carousel thumbnail
add_image_size('saasland_770x480', 770, 480, true); // Blog list thumbnail
add_image_size('saasland_570x340', 570, 340, true);
add_image_size('saasland_110x80', 110, 80, true);
add_image_size('saasland_800x400', 800, 400, true);
add_image_size('saasland_455x600', 455, 600, true);
add_image_size('saasland_520x300', 520, 300, true);
add_image_size('saasland_75x75', 75, 75, true);
add_image_size('saasland_240x200', 240, 200, true);
add_image_size('saasland_370x350', 370, 350, true);
add_image_size('saasland_240x250', 240, 250, true);
add_image_size('saasland_350x365', 350, 365, true); // Related post thumb in full width mode

// add category nick names in body and post class
function saasland_post_class( $classes ) {
    global $post;
    if( !has_post_thumbnail() ) {
        $classes[] = 'no-post-thumbnail';
    }
    return $classes;
}
add_filter( 'post_class', 'saasland_post_class' );


// Body classes
add_filter( 'body_class', function($classes) {
    $opt = get_option('saasland_opt');
    $shop_view_style = !empty($_GET['view']) ? $_GET['view'] : '';
    $is_header_top = isset( $opt['is_header_top'] ) ? $opt['is_header_top'] : '';
    $error_img_select = !empty( $opt['error_img_select'] ) ? $opt['error_img_select'] : '1';
    if( !has_nav_menu('main_menu') ) {
        $classes[] = 'no_main_menu';
    }
    if( $shop_view_style == 'grid' ) {
        $classes[] = 'shop_grid';
    }
    if( $shop_view_style == 'list' ) {
        $classes[] = 'shop_list';
    }
    if( $is_header_top == '1' && ( !empty( $opt['ht_left_content']) || !empty($opt['ht_right_content']) ) ) {
        $classes[] = 'header_top_shown';
    }
    if( !is_user_logged_in() ) {
        $classes[] = 'not_logged_in';
    }

    if( is_404() && $error_img_select == '2' ) {
        $classes[] = 'error_page2';
    }
    if ( is_home() ) {
        $classes[] = $opt['blog_layout'] == 'list' ? 'blog-list-layout' : '';
    }

    return $classes;
});


// Show post excerpt by default
function saasland_show_post_excerpt( $user_login, $user ) {
    $unchecked = get_user_meta( $user->ID, 'metaboxhidden_post', true );
    $key = is_array($unchecked) ? array_search( 'postexcerpt', $unchecked ) : FALSE;
    if ( FALSE !== $key ) {
        array_splice( $unchecked, $key, 1 );
        update_user_meta( $user->ID, 'metaboxhidden_post', $unchecked );
    }
}
add_action( 'wp_login', 'saasland_show_post_excerpt', 10, 2 );


// filter to replace class on reply link
add_filter('comment_reply_link', function($class){
    $class = str_replace("class='comment-reply-link", "class='comment_reply", $class);
    return $class;
});


/**
 * Add a pingback url auto-discovery header for singularly identifiable articles.
 */
function saasland_pingback_header() {
    if ( is_singular() && pings_open() ) {
        echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
    }
}
add_action( 'wp_head', 'saasland_pingback_header' );


// Move the comment field to bottom
add_filter( 'comment_form_fields', function ( $fields ) {
    $comment_field = $fields['comment'];
    unset( $fields['comment'] );
    $fields['comment'] = $comment_field;
    return $fields;
});


// Remove WordPress admin bar default CSS
add_action('get_header', function() {
    remove_action('wp_head', '_admin_bar_bump_cb');
});


// Elementor post type support
function saasland_add_cpt_support() {

    //if exists, assign to $cpt_support var
    $cpt_support = get_option( 'elementor_cpt_support' );

    //check if option DOESN'T exist in db
    if( ! $cpt_support ) {
        $cpt_support = [ 'page', 'post', 'header', 'footer', 'cs_study' ]; //create array of our default supported post types
        update_option( 'elementor_cpt_support', $cpt_support ); //write it to the database
    }

    //if it DOES exist, but header is NOT defined
    elseif( !in_array( 'header', $cpt_support ) ) {
        $cpt_support[] = 'header'; //append to array
        update_option( 'elementor_cpt_support', $cpt_support ); //update database
    }
    //if it DOES exist, but footer is NOT defined
    elseif( !in_array( 'footer', $cpt_support ) ) {
        $cpt_support[] = 'footer'; //append to array
        update_option( 'elementor_cpt_support', $cpt_support ); //update database
    }
    //if it DOES exist, but footer is NOT defined
    elseif( !in_array( 'cs_study', $cpt_support ) ) {
        $cpt_support[] = 'cs_study'; //append to array
        update_option( 'elementor_cpt_support', $cpt_support ); //update database
    }

    //otherwise do nothing, portfolio already exists in elementor_cpt_support option
}
add_action( 'after_switch_theme', 'saasland_add_cpt_support' );


// Version Notice
function saasland_notice() {
    global $current_user;
    $user_id = $current_user->ID;
    $my_theme = wp_get_theme();
    if ( !get_user_meta($user_id, 'saasland200_notice_ignore') ) {
        ?>
        <div class="notice notice-info">
            <p><?php esc_html_e( 'You just have activated the ', 'saasland' );
               echo '<strong>'.$my_theme->get( 'Name' ) . ' ' . $my_theme->get( 'Version' ).'</strong> '  ?>
               <?php esc_html_e( 'In this version we have made the following major changes. You can see the full list of changes log ', 'saasland' ); ?>
                <a href="https://is.gd/Flefc3" target="_blank"> <?php esc_html_e( 'here', 'saasland' ); ?> </a>
            </p>
            <ul>
                <li>
                    <strong> <?php esc_html_e( 'New : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( '"Job Settings > Styling" options added in the Theme Settings', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'New : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( '"Style 11 (Demo Landing)" Hero style added to "Hero Section" Elementor widget', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'New : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( '"Style Four (Demo Landing)" added in Testimonial with Ratting Elementor widget', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'New : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( '"Support Board" plugin listed in Appearance > Install Plugins (recommended plugin).', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'Fixed : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( 'Onepage demo\'s design issue ("App Hero" and "Call to Action with Image" Elementor widget)', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'Fixed : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( 'SaasLand Child Theme (version 1.1.1)', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'Tweaked : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( 'Performance improved (CSS, JS files dependency have set)', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'Tweaked : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( 'Menu settings', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'Tweaked : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( 'Typography settings', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'Tweaked : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( 'Theme Settings page style', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'Tweaked : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( 'Blog single full width in full width mode', 'saasland' ); ?>
                </li>
                <li>
                    <strong> <?php esc_html_e( 'Updated : ', 'saasland' ); ?> </strong>
                    <?php esc_html_e( 'WooCommerce outdated template files', 'saasland' ); ?>
                </li>
            </ul>
            <p> <a class="saasland-close-notice dismiss-notice" href="?saasland-ignore-notice">
                    <i class="dashicons dashicons-no-alt"></i>
                    <span> <?php esc_html_e( 'Dismiss', 'saasland' ); ?> </span>
                </a>
            </p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'saasland_notice');
add_action('switch_theme', 'saasland_notice');

function saasland_notice_ignore() {
    global $current_user;
    $user_id = $current_user->ID;
    if (isset($_GET['saasland-ignore-notice'])) {
        add_user_meta($user_id, 'saasland200_notice_ignore', 'true', true);
    }
}
add_action('admin_init', 'saasland_notice_ignore');