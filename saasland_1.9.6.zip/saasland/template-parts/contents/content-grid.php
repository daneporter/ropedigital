<div <?php post_class('col-lg-4 col-sm-6') ?>>
    <div class="blog_list_item blog_list_item_two">

        <?php
        if(has_post_thumbnail()) : ?>
            <div class="post_date">
                <h2> <?php the_time('d') ?> <span> <?php the_time('M') ?> </span></h2>
            </div>
        <?php endif; ?>

        <a href="<?php the_permalink() ?>">
            <?php the_post_thumbnail('saasland_240x250', array('class' => 'img-fluid')) ?>
        </a>

        <div class="blog_content">
            <a href="<?php the_permalink() ?>">
                <h5 class="blog_title" title="<?php the_title_attribute() ?>"> <?php saasland_limit_latter(get_the_title(), 48); ?> </h5>
            </a>
            <p> <?php saasland_limit_latter(get_the_content(), 70) ?> </p>
        </div>

    </div>
</div>